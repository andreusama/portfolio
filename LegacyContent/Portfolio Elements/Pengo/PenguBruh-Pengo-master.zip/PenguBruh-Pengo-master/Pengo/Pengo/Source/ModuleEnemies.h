#ifndef __MODULE_ENEMIES_H__
#define __MODULE_ENEMIES_H__

#include "Module.h"

#include <random>


#define MAX_ENEMIES 100

class Enemy;
struct SDL_Texture;

class ModuleEnemies : public Module
{
public:
	// Constructor
	ModuleEnemies(bool startEnabled);

	// Destructor
	~ModuleEnemies();

	// Called when the module is activated
	// Loads the necessary textures for the enemies
	bool Start() override;

	// Called at the beginning of the application loop
	// Removes all enemies pending to delete
	Update_Status PreUpdate() override;

	// Called at the middle of the application loop
	// Handles all enemies logic and spawning/despawning
	Update_Status Update() override;

	// Called at the end of the application loop
	// Iterates all the enemies and draws them
	Update_Status PostUpdate() override;

	// Called on application exit
	// Destroys all active enemies left in the array
	bool CleanUp() override;

	// Add an enemy into the queue to be spawned later
	void AddEnemy(int x, int y);

	bool EnemyInGridPosition(int x, int y);
	bool EnemyInPosition(int x, int y);
	bool NotStunnedEnemyInPosition(int x, int y);

	int PushEnemy(int fromx, int fromy, int x, int y);

	bool VictoryCheck(bool win);

	void WallPushed(int wallID);

	void Reset();

	bool fx_once;
	//This wil determine wether or not there are enemies on screen
	int winCounter;

	void NextColor();

	int GetColor() { return color; };

	void Suicide();

	void Pause();

	void Unpause();

	bool enemyHasDied = false;

	float suicideTimer = 0.0f;

private:


private:

	// All spawned enemies in the scene
	Enemy* enemies[MAX_ENEMIES] = { nullptr };

	// The enemies sprite sheet
	SDL_Texture* texture = nullptr;

	char color = 0;
};

#endif // __MODULE_ENEMIES_H__