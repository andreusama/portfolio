# Task List

**Eduard Minguell:** Levels configuration, music, game pad, input system, debug functionality, enemy AI, egg blocks, wall mechanic, polishing, general bug fixes.

**Telmo Beroiz:**  Player controller, score system, diamond blocks and normal blocks, animations, block pushing mechanic, input system, enemy bug fixes, renderer bug fixes and sound bug fixes.

**Andrés Sánchez:** Sound FX, debug functionality (including placing and breaking blocks, choosing level, godmode...), diamond blocks, animations, block pushing mechanic, input system, fullscreen and menu.

**Oscar Cuatrecasas:** Bonus points, enemy AI, intermission scene, UI, player controller, memory leaks, block mechanic, input system, polishing, general bug fixes.



**Note:** Some tasks were completed by more than one developer. Some tasks were completed using pair programming and don't have git commits from all members (eg. input system).
